 class MercedesCar extends Mercedes {
    @Override
     void display() {
        System.out.println("mercedes car");
    }
}
