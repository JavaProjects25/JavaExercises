enum Type {
    Car,
    Truck
}
