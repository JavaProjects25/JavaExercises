 abstract  class Volvo {
     abstract void display();
}
