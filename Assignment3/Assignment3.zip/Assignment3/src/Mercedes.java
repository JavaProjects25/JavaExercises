 abstract class Mercedes {
     abstract void display();
}
