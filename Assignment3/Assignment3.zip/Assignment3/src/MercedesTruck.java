 class MercedesTruck extends Mercedes {
      void display(){
        System.out.println("mercedes truck");
    }
}
