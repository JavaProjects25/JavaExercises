 class VolvoTruck extends Volvo {
    @Override
     void display(){
        System.out.println("volvo truck");
    }
}
