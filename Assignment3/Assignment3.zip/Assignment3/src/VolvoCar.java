 class VolvoCar extends Volvo {
    @Override
     void display(){
        System.out.println("volvo car");
    }
}
