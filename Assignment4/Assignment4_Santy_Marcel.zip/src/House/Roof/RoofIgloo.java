package House.Roof;

public class RoofIgloo implements IRoof {
    @Override
    public void display() {
        System.out.println("Roof Igloo");
    }
}
