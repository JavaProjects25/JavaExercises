package House.Roof;

public interface IRoof {
    void display();
}
