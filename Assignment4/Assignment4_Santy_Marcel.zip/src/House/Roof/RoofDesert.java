package House.Roof;

public class RoofDesert implements IRoof {
    @Override
    public void display() {
        System.out.println("Roof Desert");
    }
}
