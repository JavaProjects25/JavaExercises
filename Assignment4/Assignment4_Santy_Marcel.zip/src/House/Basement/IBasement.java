package House.Basement;

public interface IBasement {
    void display();
}
