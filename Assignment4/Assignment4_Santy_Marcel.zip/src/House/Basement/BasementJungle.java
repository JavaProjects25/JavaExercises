package House.Basement;

public class BasementJungle implements IBasement {
    @Override
    public void display() {
        System.out.println("Basement Jungle");
    }
}
