package House.Structure;

public interface IStructure {
    void display();
}
