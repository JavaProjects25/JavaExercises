package House.Structure;

public class StructureDesert implements IStructure {
    @Override
    public void display() {
        System.out.println("Structure Desert");
    }
}
