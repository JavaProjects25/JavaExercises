package House.Structure;

public class StructureIgloo implements IStructure {
    @Override
    public void display() {
        System.out.println("Structure Igloo");
    }
}
