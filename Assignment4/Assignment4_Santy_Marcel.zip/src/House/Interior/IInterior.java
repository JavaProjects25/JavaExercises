package House.Interior;

public interface IInterior {
    void display();
}
