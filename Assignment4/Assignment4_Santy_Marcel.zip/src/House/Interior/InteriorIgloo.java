package House.Interior;

public class InteriorIgloo implements IInterior {
    @Override
    public void display() {
        System.out.println("Interior Igloo");
    }
}
