package House.Interior;

public class InteriorJungle implements IInterior {
    @Override
    public void display() {
        System.out.println("Interior Jungle");
    }
}
