package Core;

public enum Product_Type {

    DesertFactory,
    IglooFactory,
    JungleFactory
}
