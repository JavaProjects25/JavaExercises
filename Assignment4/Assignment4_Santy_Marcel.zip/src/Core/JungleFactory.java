package Core;

import Condo.Condo;
import House.House;

public class JungleFactory  extends AbstractFactory {

    @Override
    public House makeHouse()
    {
        //to implement
        return null;
    }

    @Override
    public Condo makeCondo()
    {//to implement
        return null;
    }
}
