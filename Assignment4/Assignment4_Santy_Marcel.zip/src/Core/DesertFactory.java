package Core;

import House.House;
import Condo.Condo;

public class DesertFactory extends AbstractFactory {

    @Override
    public House makeHouse()
    {//to implement
        return null;
    }

    @Override
    public Condo makeCondo()
    {//to implement
        return null;
    }


}
