package Condo.Structure;

public interface IStructure {

    void display();
}
