package Condo.Structure;

public class StructureJungle implements IStructure {

    @Override
    public void display() {
        System.out.println("Structure: Jungle Theme");
    }
}
