package Condo.Basement;

public interface IBasement {

    void display();
}
