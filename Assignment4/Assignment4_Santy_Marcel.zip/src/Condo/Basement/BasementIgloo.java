package Condo.Basement;

public class BasementIgloo implements IBasement{
    @Override
    public void display() {
        System.out.println("Basement: Igloo Theme");
    }
}
