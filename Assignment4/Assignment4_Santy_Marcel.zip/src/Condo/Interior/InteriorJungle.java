package Condo.Interior;

public class InteriorJungle implements IInterior {
    @Override
    public void display() {
        System.out.println("Interior: Jungle Theme");
    }
}
