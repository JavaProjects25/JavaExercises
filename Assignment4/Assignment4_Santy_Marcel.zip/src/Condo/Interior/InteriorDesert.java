package Condo.Interior;

public class InteriorDesert implements IInterior{

    @Override
    public void display(){
        System.out.println("Interior: Desert Theme");
    }
}
