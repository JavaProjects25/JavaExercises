package Condo.Interior;

public interface IInterior {

    void display();
}
