package Condo.Roof;

public class RoofJungle implements IRoof {

    @Override
    public void display() {
        System.out.println("Roof: Jungle Theme");
    }
}
