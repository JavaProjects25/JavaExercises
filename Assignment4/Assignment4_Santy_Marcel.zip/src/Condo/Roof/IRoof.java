package Condo.Roof;

public interface IRoof {

    void display();
}
