package Interfaces;

public interface IEngineersPriority {


    void handleStamina(int staminaRequired);
}
