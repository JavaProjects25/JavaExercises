package AfterState;

public interface IState {

    void mood(Lion simba);
}
