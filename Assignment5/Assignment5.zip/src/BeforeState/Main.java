package BeforeState;

public class Main {
    public static void main(String[] args) {

        Lion simba = new Lion();
        simba.changeState();
        simba.changeState();
        simba.changeState();

    }
}