interface IEnergySource {
    String getEnergyType();
}
