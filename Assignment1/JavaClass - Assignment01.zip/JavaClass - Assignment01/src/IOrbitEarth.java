interface IOrbitEarth extends IFlightEnabled {
    void achieveOrbit();
}
