interface IAutopilot {
    void engageAutopilot();
}
