interface IFlightEnabled {
    void takeOff();
    void land();
    void fly();
}
