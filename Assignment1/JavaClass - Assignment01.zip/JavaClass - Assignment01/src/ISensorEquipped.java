interface ISensorEquipped {
    void readSensors();
}
