interface IMilitary {
    void deployWeapon();
}
