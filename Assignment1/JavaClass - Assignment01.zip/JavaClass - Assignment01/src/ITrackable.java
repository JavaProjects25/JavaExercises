interface ITrackable {
    void track();
}

