abstract class Animal {

    abstract void move();
}
