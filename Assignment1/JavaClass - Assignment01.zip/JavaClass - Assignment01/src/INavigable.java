interface INavigable {
    void setDestination(String destination);
}
