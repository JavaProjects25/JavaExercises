 enum FlightStage {
     GROUNDED,
     LAUNCH,
     CRUISE,
     DATA_COLLECTION
}
