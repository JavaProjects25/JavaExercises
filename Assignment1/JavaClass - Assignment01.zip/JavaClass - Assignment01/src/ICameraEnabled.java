interface ICameraEnabled {
    void captureImage();
}
