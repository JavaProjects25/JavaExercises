interface ICommunicable {
    void transmitData();
}
