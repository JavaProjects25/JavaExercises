package State;

public interface IState {

    void paymentState();
}
