package Adapters;

public enum EOldCoffee {
    SMALLCOFFEE,
    LARGECOFFEEWITHMILK,
}
