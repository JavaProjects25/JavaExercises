package Enums;

public enum EState {
    NotTired,
    Tired
}
