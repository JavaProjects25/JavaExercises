package Interfaces;

import Enums.EState;
public interface IObserver {

    void update(String availability);
}
