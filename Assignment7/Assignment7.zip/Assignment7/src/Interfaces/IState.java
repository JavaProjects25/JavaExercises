package Interfaces;

public interface IState {

    void changeState();
}
